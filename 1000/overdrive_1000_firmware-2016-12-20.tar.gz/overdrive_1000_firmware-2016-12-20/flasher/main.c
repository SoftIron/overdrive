/*
 * M-Stack USB Bootloader
 *
 *  M-Stack is free software: you can redistribute it and/or modify it under
 *  the terms of the GNU Lesser General Public License as published by the
 *  Free Software Foundation, version 3; or the Apache License, version 2.0
 *  as published by the Apache Software Foundation.  If you have purchased a
 *  commercial license for this software from Signal 11 Software, your
 *  commerical license superceeds the information in this header.
 *
 *  M-Stack is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 *  License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this software.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  You should have received a copy of the Apache License, verion 2.0 along
 *  with this software.  If not, see <http://www.apache.org/licenses/>.
 *
 * Alan Ott
 * Signal 11 Software
 * 2013-04-29
 */

/* C */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#if _MSC_VER && _MSC_VER < 1600
	#include "c99.h"
#else
	#include <inttypes.h>
	#include <stdbool.h>
#endif

#include "hex.h"
#include "flasher.h"
#include "../common/flasher_usb_protocol.h"

#ifdef WIN32
	#include <Windows.h>
	#define sleep(X) Sleep(X*1000)
#else
	#include <unistd.h>
#endif

/* Change these for your application */
#define DEFAULT_VID 0x2e02
#define DEFAULT_PID 0x1000

static bool verbose_output = false;
#define info(...) do { if (verbose_output) printf(__VA_ARGS__); } while(0)

static void print_usage(const char *prog_name)
{
	printf("Usage: %s [OPTION]... FILE\n", prog_name);
	printf("Flash firmware or EEPROM file for Overdrive 1000.\n\n");
	printf("OPTIONS can be one of:\n");
	printf("  -d  --dev=VID:PID     USB VID/PID of the device to program\n");
	printf("  -p  --program         Write to the flash memory\n");
	printf("  -v, --verify          verify program write\n");
	printf("      --read            read data from the device\n");
#ifdef SET_MAC
	printf("      --mac=MAC_ADDR    Set MAC address\n");
#endif
	printf("  -f, --flash           write to the SPI flash\n");
	printf("  -e, --eeprom          write to the EEPROM\n");
	printf("  -l  --verbose         Verbose (loud) output\n");
	printf("  -h, --help            print help message and exit\n\n");
	printf("If FILE has an extension of HEX or hex, it will be treated\n");
	printf("as Intel Hex format (ihex). Otherwise it will be treated\n");
	printf("a raw binary file.\n");
	printf("Use a single hyphen (-) to read firmware hex file from stdin.\n");
}

static bool parse_vid_pid(const char *str, uint16_t *vid, uint16_t *pid)
{
	const char *colon;
	char *endptr;
	int val;

	/* check the format */
	if (!*str)
		return false;
	colon = strchr(str, ':');
	if (!colon)
		return false;
	if (!colon[1])
		return false;
	if (colon == str)
		return false;

	/* VID */
	val = strtol(str, &endptr, 16);
	if (*endptr != ':')
		return false;
	if (val > 0xffff)
		return false;
	*vid = val;

	/* PID */
	val = strtol(colon+1, &endptr, 16);
	if (*endptr != '\0')
		return false;
	if (val > 0xffff)
		return false;
	*pid = val;
	
	return true;
}

#ifdef SET_MAC
/* Check that the MAC address is parsable as 12 hex characters. */
static bool parse_mac(const char *str)
{
	int i;

	/* Check Length */
	if (strlen(str) != 12)
		return false;

	/* Check that it's all hex digits. */
	for (i = 0; i < 12; i++) {
		if (!isxdigit(str[i]))
			return false;
	}

	return true;
}
#endif

int main(int argc, char **argv)
{
	bool do_program = false;
	bool do_verify = false;
	bool do_read = false;
#ifdef SET_MAC
	bool do_mac = false;
#endif
	bool use_flash = false;
	bool use_eeprom = false;
	bool factory_setup = false;
#ifdef SET_MAC
	const char *mac_address = NULL;
#endif
	char **itr;
	const char *opt;
	const char *filename = NULL;
	uint16_t vid = 0, pid = 0;
	bool vidpid_valid = false;
	struct bootloader *bl;
	enum target target = TARGET_FLASH;
	const char *target_str;
	int res;

	if (argc < 2) {
		print_usage(argv[0]);
		return 1;
	}
	
	/* Parse the command line. */
	itr = argv+1;
	opt = *itr;
	while (opt) {
		if (opt[0] == '-') {
			/* Option parameter */
			if (opt[1] == '-') {
				/* Long option, two dashes. */
				if (!strcmp(opt, "--help")) {
					print_usage(argv[0]);
					return 1;
				}
				else if (!strcmp(opt, "--program"))
					do_program = true;
				else if (!strcmp(opt, "--verify"))
					do_verify = true;
				else if (!strcmp(opt, "--read"))
					do_read = true;
				else if (!strcmp(opt, "--flash"))
					use_flash = true;
				else if (!strcmp(opt, "--eeprom"))
					use_eeprom = true;
				else if (!strcmp(opt, "--verbose"))
					verbose_output = true;
#if SET_MAC
				else if (!strncmp(opt, "--mac", 5)) {
					bool mac_valid;
					if (opt[5] != '=') {
						fprintf(stderr, "--mac requires a mac 6-byte address of the form 0123456789AB\n\n");
						return 1;
					}
					mac_valid = parse_mac(opt+6);
					if (!mac_valid) {
						fprintf(stderr, "Invalid MAC address, requires 6-bytes of the form 01234567890AB\n\n");
						return 1;
					}
					mac_address = opt+6;
					factory_setup = true;
					do_mac = true;
				}
#endif
				else if (!strncmp(opt, "--dev", 5)) {
					if (opt[5] != '=') {
						fprintf(stderr, "--dev requires vid/pid pair\n\n");
						return 1;
					}
					vidpid_valid = parse_vid_pid(opt+6, &vid, &pid);
					if (!vidpid_valid) {
						fprintf(stderr, "Invalid VID/PID pair\n\n");
						return 1;
					}
				}
				else {
					fprintf(stderr, "Invalid Parameter %s\n\n", opt);
					return 1;
				}
			}
			else {
				const char *c = opt + 1;
				if (!*c) {
					/* This is a parameter of a single
					   hyphen, which means read from
					   stdin. */
					filename = opt;
				}
				while (*c) {
					/* Short option, only one dash */
					switch (*c) {
					case 'p':
						do_program = true;
						break;
					case 'v':
						do_verify = true;
						break;
					case 'f':
						use_flash = true;
						break;
					case 'e':
						use_eeprom = true;
						break;
					case 'l':
						verbose_output = true;
						break;
					case 'd':
						itr++;
						opt = *itr;
						if (!opt) {
							fprintf(stderr, "Must specify vid:pid after -d\n\n");
							return 1;
						}
						vidpid_valid = parse_vid_pid(opt, &vid, &pid);
						if (!vidpid_valid) {
							fprintf(stderr, "Invalid VID/PID pair\n\n");
							return 1;
						}
						break;
					default:
						fprintf(stderr, "Invalid parameter '%c'\n\n", *c);
						return 1;
					}
					c++;
				}
			}
		}
		else {
			/* Doesn't start with a dash. Must be the filename */
			if (filename) {
				fprintf(stderr, "Multiple filenames listed. This is not supported\n\n");
				return 1;
			}
			
			filename = opt;
		}
		itr++;
		opt = *itr;
	}

	vid = vidpid_valid? vid: DEFAULT_VID;
	pid = vidpid_valid? pid: DEFAULT_PID;
	
	if (!filename && !factory_setup) {
	        fprintf(stderr, "No Filename specified. Specify a filename of use \"-\" to read from stdin.\n");
	        return 1;
	}

	if (!use_flash && !use_eeprom && !factory_setup) {
	        fprintf(stderr, "Target not specified. Must specify --flash or --eeprom.\n");
	        return 1;
	}

	if (use_flash && use_eeprom) {
	        fprintf(stderr, "Multiple targets specified. Must specify only one of --flash or --eeprom.\n");
	        return 1;
	}

	if (do_read && do_verify) {
		fprintf(stderr, "Options --read and --verify are incompatible.");
		return 1;
	}

	if (do_read && do_program) {
		fprintf(stderr, "Options --read and --program are incompatible.");
		return 1;
	}

	if (use_flash)
		target = TARGET_FLASH;
	else if (use_eeprom)
		target = TARGET_EEPROM;

	if (target == TARGET_FLASH)
		target_str = "flash";
	else if (target == TARGET_EEPROM)
		target_str = "EEPROM";
	else {
		fprintf(stderr, "Invalid target %d", target);
		target_str = NULL; /* To avoid uninitialized warning */
		return 1;
	}

	/* Command line parsing is done. Do the programming of the device. */

	/* Open the device */
	info("Opening the Overdrive 1000 flasher device.\n");
	res = bootloader_init(&bl, target, (do_read)? NULL: filename, vid, pid);
	if (res == BOOTLOADER_CANT_OPEN_FILE) {
		fprintf(stderr, "Unable to open file %s\n", filename);
		return 1;
	}
	else if (res == BOOTLOADER_CANT_OPEN_DEVICE) {
		fprintf(stderr, "\nUnable to open device %04hx:%04hx "
			"for programming.\n"
			"Make sure that the device is connected "
			"and that you have proper permissions\nto "
			"open it.\n", vid, pid);
		return 1;
	}
	else if (res == BOOTLOADER_CANT_QUERY_DEVICE) {
		fprintf(stderr, "Unable to query device parameters\n");
		return 1;
	}
	else if (res == BOOTLOADER_MULTIPLE_CONNECTED) {
		fprintf(stderr, "Multiple devices are connected. Remove all but one.\n");
	}
	else if (res < 0) {
		fprintf(stderr, "Unspecified error initializing bootloader %d\n", res);
		return 1;
	}
	
	if (do_verify || do_program || do_read) {
		/* Hold the device in reset */
		info("Holding Device in Reset.\n");
		res = bootloader_hold_in_reset(bl, true);
		if (res < 0) {
			fprintf(stderr, "Reset of SoC failed\n");
			return 1;
		}
	}

	if (do_program) {
		/* Erase */
		info("Erasing %s.\n", target_str);
		res = bootloader_erase(bl);
		if (res < 0) {
			fprintf(stderr, "Erasing of device failed\n");
			return 1;
		}

		/* Program */
		info("Programming %s.\n", target_str);
		res = bootloader_program(bl);
		if (res < 0) {
			fprintf(stderr, "Programming of device failed\n");
			return 1;
		}
	}

	/* Verify */
	if (do_verify) {
		info("Verifying %s.\n", target_str);
		res = bootloader_verify(bl);
		if (res < 0) {
			fprintf(stderr, "Verification of programmed memory failed\n");
			return 1;
		}
	}

	/* Read */
	if (do_read) {
		info("Reading %s.\n", target_str);
		res = bootloader_read(bl, filename);
		if (res < 0) {
			fprintf(stderr, "Reading of programmed memory failed\n");
			return 1;
		}
	}

#ifdef SET_MAC
	/* Set Mac Address */
	if (do_mac) {
		info("Setting the MAC address.\n");
		res = bootloader_set_mac(bl, mac_address);
		if (res < 0) {
			fprintf(stderr, "Programming of MAC address failed. "
			                "Make sure power is applied to the Overdrive 1000.\n");
			return 1;
		}
	}
#endif

	/* Release SoC from reset */
	res = bootloader_hold_in_reset(bl, false);
	if (res < 0) {
		fprintf(stderr, "Release-from-Reset of SoC failed\n");
		return 1;
	}

	/* Close */
	bootloader_free(bl);

	info("Done.\n");

	return 0;
}
