OverDrive 1000 Firmware Package
================================

See the OverDrive 1000 manual, which can be downloaded from
http://support.softiron.com for detailed instructions. This file should
be considered a quick reference guide for firmware updates.

Prerequisites
--------------

Before building the flasher and bootloader tools, a compiler and the
libusb-1.0 developemnt files must be installed on the host system.

For SUSE Linux systems:
    zypper install gcc make libusb-1_0-devel

For Debian-based systems (including Ubuntu):
    sudo apt-get install build-essential libusb-1.0-0-dev

Updating the UEFI image
------------------------

1. Build the flasher tool
    make -C flasher/

2. Press the and hold the button on the back of the case for 5 seconds to
   unlock the flasher functionality.

3. Flash the firmware image
    sudo ./flasher/flasher --program --verify OVERDRIVE1000_ROM.fd --verbose --flash

Note: The above can also be used to flash user-built firmware images.

Updating the EEPROM
--------------------

0. Note that this is not typically necessary, but can be used to clear
   memory training data.

1. Build the flasher tool
    make -C flasher/

2. Press the and hold the button on the back of the case for 5 seconds to
   unlock the flasher functionality.

3. Flash the eeprom image
    sudo ./flasher/flasher --program --verify od1000_eeprom.bin --verbose --eeprom

Updating the PIC32 Firmware
----------------------------

OverDrive 1000 has a PIC32 microcontroller which implements the USB console,
programs the UEFI flash and EEPROM, and controls the fans. If the PIC32
needs to be updated, use the following procedure:

1. Build the bootloader
    make -C bootloader/

2. Power off the OverDrive 1000 and unplug the power cable.

3. Unplug the OverDrive 1000's USB console.

4. Press and hold the maintenance button on the back of the OverDrive 1000
   case.  While holding the maintenance button, plug the USB Console into a
   Linux PC.  (The main power should remain unplugged).

5. If you then run dmesg on the Linux PC, you'll see the last messages:
   usb 1-4.3.2:  new full-speed USB device number 82 using ehci-pci
   usb 1-4.3.2:  New USB device found, idVendor=2e02, idProduct=1001
   usb 1-4.3.2:  New USB device strings: Mfr=1, Product=2, SerialNumber=0
   usb 1-4.3.2:  Product: OverDrive 1000 Bootloader
   usb 1-4.3.2:  Manufacturer: SoftIron, Inc.

6. Write the PIC32 firmware:
   sudo ./bootloader/bootloader pic32_firmware.hex --verify --reset

Software Revisions
-------------------

Tools from git revision 465c735bdfd83a82b3e94d01fcb32a7e2a2779ae
UEFI/edk2 from git revision a4bcf0bcdd81285e2ae881db7a51a454f8ab0951
UEFI/OpenPlatformPkg from git revision 6612138b9237a78564c03556520c4ba86ade4348
Build Date: 2016-12-20
