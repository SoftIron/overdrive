Overdrive 1000 Binary Package
------------------------------

To install a new Overdrive 1000 board:

0. Program the MCP19119, whose procedure is outside the scope of this
document, because it requires manual tuning of parameters in the source
code.

1. Install pic32_bootloader.hex using the MPLAB IPE.
a. Open the MPLAB IPE
b. Select PIC32MX470F512L as the device and press Apply.
c. Connect the programmer to the board
d. Select the programmer under the Tool drop down.
e. Press Connect
f. Select Settings->Advanced Mode from the menu
g. Log in with password ("microchip" by default)
h. To the right of the "Source" line, select Browse.
i. Select pic32_bootloader.hex from the this directory.
j. Press Program. Look for "Programming/Verify complete" in the output

2. Using the bootloader tool from this directory, install the main firmware:
    sudo ./bootloader pic32_firmware.hex --verify

3. Using the bootloader tool from this directory, set the serial number:
    sudo ./bootloader --serial=my_serial_num --reset

4. Press and hold the button on the back of the case for 5 seconds. This
   unlocks the flasher functionality.

5. Using the flasher tool from this directory, install the Seattle ROM:
    sudo ./flasher --program --verify OVERDRIVE1000_ROM.fd --verbose --flash

6. Using the flasher tool from this directory, install the Seattle EEPROM:
    sudo ./flasher --program --verify od1000_eeprom.bin --verbose --eeprom

7. Using the flasher tool from this directory, set the MAC address:
    sudo ./flasher --mac=001122334455

Software Revisions
-------------------

Tools from git revision ee1fa0332ecf9f498f4a9c3012d6341d65a3ae4c
UEFI/edk2 from git revision a4bcf0bcdd81285e2ae881db7a51a454f8ab0951
UEFI/OpenPlatformPkg from git revision 6612138b9237a78564c03556520c4ba86ade4348
PIC32 firmware version: 1.02
Build Date: 2017-01-19
